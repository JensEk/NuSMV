/* config.h for DJGPP v2.  Generated from config.h.in.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Almost everything is defined for us on <sys/config.h>  */

#include <sys/config.h>

/* Define if you have alloca, as a function or macro.  */
#define HAVE_ALLOCA 1

/* Define to use grep's error-checking malloc in the kwset routines.  */
#define GREP 1

/* Package name. */
#define PACKAGE "grep"

/* Version number. */
#define VERSION "2.1.1"

/* Define if you have the <malloc.h> header file.  */
#define HAVE_MALLOC_H 1

/* Define if you have the <memory.h> header file.  */
#define HAVE_MEMORY_H 1

/* Define if you have the setrlimit function.  */
#define HAVE_SETRLIMIT 1
